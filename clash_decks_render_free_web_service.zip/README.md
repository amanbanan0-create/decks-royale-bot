# Clash Decks Bot — Render

## Render settings

Service type: Web Service
Language: Python 3
Branch: main
Build Command: pip install -r requirements.txt
Start Command: uvicorn bot:app --host 0.0.0.0 --port $PORT
Plan: Free

## Environment Variables

BOT_TOKEN = token from @BotFather
ADMIN_IDS = your numeric Telegram ID
WEBHOOK_SECRET = any private random string

Render automatically provides RENDER_EXTERNAL_URL. The bot uses it to register its Telegram webhook.

## Important

This is a prototype. Decks and favorites are currently stored in memory and will be lost after restarts/redeploys. The next version should use PostgreSQL.
