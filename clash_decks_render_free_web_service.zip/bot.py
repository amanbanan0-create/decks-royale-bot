import asyncio
import logging
import os
from dataclasses import dataclass

from fastapi import FastAPI, Header, HTTPException, Request
from dotenv import load_dotenv
from aiogram import Bot, Dispatcher, F
from aiogram.filters import Command, CommandStart
from aiogram.types import Message, CallbackQuery, InlineKeyboardMarkup, InlineKeyboardButton, Update
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import State, StatesGroup

load_dotenv()

TOKEN = os.getenv("BOT_TOKEN")
ADMIN_IDS_RAW = os.getenv("ADMIN_IDS", "")
WEBHOOK_SECRET = os.getenv("WEBHOOK_SECRET", "clash-decks-secret")

if not TOKEN:
    raise RuntimeError("BOT_TOKEN is not set")

RENDER_EXTERNAL_URL = os.getenv("RENDER_EXTERNAL_URL", "").rstrip("/")
if not RENDER_EXTERNAL_URL:
    # Local development fallback
    RENDER_EXTERNAL_URL = os.getenv("PUBLIC_URL", "").rstrip("/")

WEBHOOK_PATH = "/telegram/webhook"
WEBHOOK_URL = f"{RENDER_EXTERNAL_URL}{WEBHOOK_PATH}" if RENDER_EXTERNAL_URL else ""

@dataclass
class Deck:
    id: int
    name: str
    cards: list[str]
    mode: str
    win_rate: float
    games: int
    source: str = "manual"

decks = [
    Deck(
        1, "Hog Rider Cycle",
        ["Hog Rider", "Musketeer", "Cannon", "Fireball",
         "The Log", "Ice Spirit", "Skeletons", "Ice Golem"],
        "ladder", 54.2, 12000
    ),
    Deck(
        2, "Giant Graveyard",
        ["Giant", "Graveyard", "Baby Dragon", "Tornado",
         "Poison", "Barbarian Barrel", "Ice Wizard", "Tombstone"],
        "ladder", 53.7, 9800
    ),
]
favorites: dict[int, set[int]] = {}
next_deck_id = 3

class AddDeck(StatesGroup):
    name = State()
    cards = State()
    mode = State()
    win_rate = State()
    games = State()

dp = Dispatcher()

def main_menu():
    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="🔥 Мета", callback_data="meta"),
         InlineKeyboardButton(text="🏆 Топ колоды", callback_data="top")],
        [InlineKeyboardButton(text="🎯 Испытания", callback_data="challenges"),
         InlineKeyboardButton(text="🔍 Поиск", callback_data="search")],
        [InlineKeyboardButton(text="⭐ Избранное", callback_data="favorites"),
         InlineKeyboardButton(text="➕ Добавить", callback_data="add_deck")],
    ])

def back_button():
    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="⬅️ Назад", callback_data="home")]
    ])

def deck_keyboard(deck_id: int):
    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="🃏 Открыть", callback_data=f"deck:{deck_id}"),
         InlineKeyboardButton(text="⭐", callback_data=f"fav:{deck_id}")]
    ])

def get_deck(deck_id: int):
    return next((d for d in decks if d.id == deck_id), None)

def deck_text(deck: Deck):
    cards = "\n".join(f"• {c}" for c in deck.cards)
    return (
        f"🃏 <b>{deck.name}</b>\n\n{cards}\n\n"
        f"🎮 Режим: <b>{deck.mode}</b>\n"
        f"📈 Win rate: <b>{deck.win_rate}%</b>\n"
        f"⚔️ Игр: <b>{deck.games:,}</b>\n"
        f"📡 Источник: <b>{deck.source}</b>"
    )

def is_admin(user_id: int) -> bool:
    try:
        admins = {int(x.strip()) for x in ADMIN_IDS_RAW.split(",") if x.strip()}
        return user_id in admins
    except ValueError:
        return False

@dp.message(CommandStart())
async def start(message: Message):
    await message.answer(
        "🏠 <b>Clash Decks</b>\n\n"
        "Актуальные колоды Clash Royale.\n\n"
        "Выбери раздел:",
        reply_markup=main_menu()
    )

@dp.callback_query(F.data == "home")
async def home(callback: CallbackQuery):
    await callback.message.edit_text(
        "🏠 <b>Clash Decks</b>\n\nВыбери раздел:",
        reply_markup=main_menu()
    )
    await callback.answer()

@dp.callback_query(F.data == "meta")
async def meta(callback: CallbackQuery):
    sorted_decks = sorted(decks, key=lambda x: x.win_rate, reverse=True)
    text = "🔥 <b>МЕТА</b>\n\n"
    for i, deck in enumerate(sorted_decks[:5], 1):
        text += f"{i}. <b>{deck.name}</b>\n📈 {deck.win_rate}% WR\n⚔️ {deck.games:,} игр\n\n"
    await callback.message.edit_text(text, reply_markup=back_button())
    await callback.answer()

@dp.callback_query(F.data == "top")
async def top(callback: CallbackQuery):
    sorted_decks = sorted(decks, key=lambda x: x.games, reverse=True)
    text = "🏆 <b>ТОП КОЛОД</b>\n\n"
    for deck in sorted_decks[:5]:
        text += f"🃏 <b>{deck.name}</b>\n⚔️ {deck.games:,} игр\n📈 {deck.win_rate}% WR\n\n"
    await callback.message.edit_text(text, reply_markup=back_button())
    await callback.answer()

@dp.callback_query(F.data == "challenges")
async def challenges(callback: CallbackQuery):
    await callback.message.edit_text(
        "🎯 <b>ИСПЫТАНИЯ</b>\n\n"
        "Раздел готов к подключению актуальных испытаний "
        "и лучших колод для каждого из них.",
        reply_markup=back_button()
    )
    await callback.answer()

@dp.callback_query(F.data == "search")
async def search_start(callback: CallbackQuery, state: FSMContext):
    await state.set_state("searching")
    await callback.message.edit_text(
        "🔍 Напиши название карты или архетип.\n\n"
        "Например: <code>Hog Rider</code>",
        reply_markup=back_button()
    )
    await callback.answer()

@dp.message(F.text)
async def text_router(message: Message, state: FSMContext):
    current_state = await state.get_state()
    if current_state != "searching":
        return
    query = message.text.lower()
    results = [
        d for d in decks
        if query in d.name.lower() or any(query in c.lower() for c in d.cards)
    ]
    if not results:
        await message.answer("😔 Ничего не найдено.", reply_markup=main_menu())
    else:
        for deck in results[:10]:
            await message.answer(deck_text(deck), reply_markup=deck_keyboard(deck.id))
    await state.clear()

@dp.callback_query(F.data.startswith("deck:"))
async def show_deck(callback: CallbackQuery):
    deck = get_deck(int(callback.data.split(":")[1]))
    if not deck:
        await callback.answer("Колода не найдена", show_alert=True)
        return
    await callback.message.edit_text(deck_text(deck), reply_markup=deck_keyboard(deck.id))
    await callback.answer()

@dp.callback_query(F.data.startswith("fav:"))
async def favorite(callback: CallbackQuery):
    deck_id = int(callback.data.split(":")[1])
    user_id = callback.from_user.id
    favorites.setdefault(user_id, set())
    if deck_id in favorites[user_id]:
        favorites[user_id].remove(deck_id)
        await callback.answer("Удалено из избранного")
    else:
        favorites[user_id].add(deck_id)
        await callback.answer("⭐ Добавлено в избранное")

@dp.callback_query(F.data == "favorites")
async def show_favorites(callback: CallbackQuery):
    ids = favorites.get(callback.from_user.id, set())
    if not ids:
        text = "⭐ <b>ИЗБРАННОЕ</b>\n\nЗдесь пока ничего нет."
    else:
        text = "⭐ <b>ИЗБРАННОЕ</b>\n\n"
        for deck_id in ids:
            deck = get_deck(deck_id)
            if deck:
                text += f"🃏 {deck.name}\n📈 {deck.win_rate}% WR\n\n"
    await callback.message.edit_text(text, reply_markup=back_button())
    await callback.answer()

@dp.callback_query(F.data == "add_deck")
async def add_deck_start(callback: CallbackQuery, state: FSMContext):
    if not is_admin(callback.from_user.id):
        await callback.answer("⛔ Только для администратора.", show_alert=True)
        return
    await state.set_state(AddDeck.name)
    await callback.message.edit_text("➕ <b>Добавление колоды</b>\n\nШаг 1/5\nНазвание:")
    await callback.answer()

@dp.message(AddDeck.name)
async def add_name(message: Message, state: FSMContext):
    await state.update_data(name=message.text)
    await state.set_state(AddDeck.cards)
    await message.answer("Шаг 2/5\nВведи 8 карт через запятую.")

@dp.message(AddDeck.cards)
async def add_cards(message: Message, state: FSMContext):
    cards = [x.strip() for x in message.text.split(",") if x.strip()]
    if len(cards) != 8:
        await message.answer("❌ Нужно ровно 8 карт.")
        return
    await state.update_data(cards=cards)
    await state.set_state(AddDeck.mode)
    await message.answer("Шаг 3/5\nРежим, например: ladder")

@dp.message(AddDeck.mode)
async def add_mode(message: Message, state: FSMContext):
    await state.update_data(mode=message.text)
    await state.set_state(AddDeck.win_rate)
    await message.answer("Шаг 4/5\nWin rate, например: 55.4")

@dp.message(AddDeck.win_rate)
async def add_win_rate(message: Message, state: FSMContext):
    try:
        value = float(message.text.replace(",", "."))
    except ValueError:
        await message.answer("❌ Введи число, например 55.4")
        return
    await state.update_data(win_rate=value)
    await state.set_state(AddDeck.games)
    await message.answer("Шаг 5/5\nКоличество игр, например: 15000")

@dp.message(AddDeck.games)
async def add_games(message: Message, state: FSMContext):
    global next_deck_id
    try:
        games = int(message.text)
    except ValueError:
        await message.answer("❌ Введи целое число.")
        return
    data = await state.get_data()
    deck = Deck(next_deck_id, data["name"], data["cards"], data["mode"], data["win_rate"], games)
    decks.append(deck)
    next_deck_id += 1
    await state.clear()
    await message.answer("✅ <b>Колода добавлена!</b>\n\n" + deck_text(deck), reply_markup=main_menu())

@dp.message(Command("admin"))
async def admin(message: Message):
    if is_admin(message.from_user.id):
        await message.answer("👑 <b>ADMIN</b>\n\nИспользуй «➕ Добавить».")
    else:
        await message.answer("⛔ Нет доступа.")

app = FastAPI()

@app.get("/")
async def root():
    return {"status": "ok", "service": "clash-decks-bot"}

@app.get("/health")
async def health():
    return {"status": "healthy"}

@app.post(WEBHOOK_PATH)
async def telegram_webhook(request: Request, x_telegram_bot_api_secret_token: str | None = Header(default=None)):
    if x_telegram_bot_api_secret_token != WEBHOOK_SECRET:
        raise HTTPException(status_code=403, detail="Forbidden")
    data = await request.json()
    update = Update.model_validate(data)
    await dp.feed_update(bot, update)
    return {"ok": True}

bot = Bot(token=TOKEN)

@app.on_event("startup")
async def startup():
    logging.basicConfig(level=logging.INFO)
    if not WEBHOOK_URL:
        logging.warning("RENDER_EXTERNAL_URL/PUBLIC_URL is missing; webhook was not configured.")
        return
    await bot.set_webhook(
        WEBHOOK_URL,
        secret_token=WEBHOOK_SECRET,
        drop_pending_updates=True
    )
    logging.info("Webhook set to %s", WEBHOOK_URL)

@app.on_event("shutdown")
async def shutdown():
    try:
        await bot.delete_webhook()
        await bot.session.close()
    except Exception:
        pass
